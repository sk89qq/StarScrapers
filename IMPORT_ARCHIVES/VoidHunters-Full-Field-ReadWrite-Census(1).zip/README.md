# Void Hunters Full Field Read/Write Census

Source:
- Original Void Hunters JAR
- SHA-256: 4bb086ef9b0ec1f6f5362df92d634a2b4d997b4b5037f213fd3d5e5ea219bba4
- Exact JAR class entries: 1570
- Complete javap source: /mnt/data/_rw_census_build/full/Darkwing-main/VOIDA/ORIGINAL_JAR/PREPROCESSING_01_06/javap-all.txt

Counts:
- field access instructions: 27512
- distinct referenced fields: 3764
- read instructions: 22876
- write instructions: 4636
- external field-write instructions: 4636
- anomalous/unclassified field instructions: 0

Method:
Each row is tied to a concrete bytecode instruction containing a JVM field opcode and a `// Field owner.field:descriptor` reference in the complete javap dump.
READ = getfield/getstatic.
WRITE = putfield/putstatic.

Completeness:
- Exhaustive for field access instructions represented in the supplied complete javap dump.
- Class inventory is exact from the JAR ZIP directory.
- This census does not infer reflection, JNI/native field access, serialization frameworks, generated code outside the JAR, or runtime behavior not represented as JVM field instructions.
- No semantic meaning is inferred from field names.
- Inheritance is not collapsed: a field owner remains the owner encoded in the bytecode reference.
- Accesses are not deduplicated in the raw ledger; every bytecode field instruction is retained.
- Summary indexes deduplicate only where explicitly stated.

Authority:
Original JAR/classfiles > javap > decompiler readability > forensic interpretation > DarkWing implementation.

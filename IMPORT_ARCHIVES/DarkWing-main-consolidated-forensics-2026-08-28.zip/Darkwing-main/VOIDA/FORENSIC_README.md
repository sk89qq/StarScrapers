# Forensic working set

Use `FORENSIC_MASTER.md` first. It is the consolidated dispatch layer and canonical status map.

## Evidence hierarchy
1. Original JAR under `ORIGINAL_JAR/` and its SHA-256.
2. JAR-derived source/disassembly and preprocessing indexes.
3. `DEFINITIVE_VALUES/` extracted native tables.
4. DarkWing implementation.

## Do not reopen
Anything marked `CLOSED-IMPLEMENTATION` in the master is applied as-is unless new JAR evidence contradicts it.

## Preserve identifiers
`FORENSIC_VARIABLE_REGISTRY.csv` contains deduplicated symbols/expressions recovered from the culled forensic notes so variable names are not lost when historical prose is removed.

## Active work
Follow only the Active forensic queue in `FORENSIC_MASTER.md`.

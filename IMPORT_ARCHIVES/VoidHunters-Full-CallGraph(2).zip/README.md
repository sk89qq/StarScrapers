# Void Hunters Full Call Graph

Source authority:
- Original Void Hunters JAR
- SHA-256: 4bb086ef9b0ec1f6f5362df92d634a2b4d997b4b5037f213fd3d5e5ea219bba4
- Exact `.class` entries: 1570

This is a mechanically extracted invocation graph from the complete `javap-all.txt` generated from the original JAR.

Outputs:
- CALL_GRAPH_EDGES.tsv: one row per unique caller→callee bytecode reference.
- CALLERS_BY_CALLEE.tsv: reverse index.
- CALL_GRAPH_COUNTS.tsv: reference counts.
- CLASS_CALL_GRAPH.tsv: class-level directed graph.
- METHOD_DECLARATIONS.tsv: parsed method declarations and whether a Code block was found.
- CLASS_COVERAGE.tsv: exact JAR class inventory versus parser-visible javap class headers.
- EXTERNAL_CALLEE_CENSUS.tsv: referenced owners not present as classes in the JAR inventory.
- FIELD_ACCESS_CENSUS.tsv: bytecode field-reference census.

Important completeness qualification:
- The class inventory is exact because it is read directly from the JAR ZIP directory.
- The call edges are complete with respect to invocation comments present in the supplied complete `javap` dump.
- This file does NOT infer dynamic reflection, invokedynamic target resolution, native/JNI behavior, or calls whose target is constructed dynamically without a visible method reference.
- No semantic names or gameplay meanings are inferred here.
- Descriptor identity is preserved wherever javap exposes it.

Authority hierarchy:
1. Original JAR/classfiles
2. javap
3. decompiler output
4. forensic interpretation
5. DarkWing implementation

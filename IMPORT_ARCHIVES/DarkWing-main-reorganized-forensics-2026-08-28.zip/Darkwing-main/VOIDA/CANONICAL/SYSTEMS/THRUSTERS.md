# Canonical Thrusters

## RECOVERED
- Native force scales include small `16`, standard `192`, booster `1024`.
- Native force projection uses the recovered 8192-unit angular domain and fixed-point trig scale.
- Native binding/autobalance path and its recovered projection thresholds are documented in the archived operator/binding reports.

## PARTIAL / OPEN
- Only game-specific producer/consumer mappings still matter; do not reconstruct the original physics engine.
- Remaining unresolved values are those explicitly required to reproduce gameplay output, not solver mechanics.

## EVIDENCE
Archived: `ARCHIVE/DUPLICATE_WORKSTREAMS/29_NATIVE_THRUSTER_OPERATOR_RECOVERY.md`, `30_NATIVE_THRUSTER_BINDING_RECOVERY.md`.

# Canonical Missions

## PARTIAL / OPEN
- Mission definitions and symbol mappings are substantially indexed.
- Mission state-transition semantics remain an active forensic target where source evidence is incomplete.
- Native timing values must be distinguished from implementation scaffolding before port use.

See `MISSION_SYMBOL_INDEX.md` and the archived mission migration report.

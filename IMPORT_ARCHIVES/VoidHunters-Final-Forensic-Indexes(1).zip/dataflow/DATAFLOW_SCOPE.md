# Dataflow Scope

These indexes provide exact invocation sites, JVM method descriptors, parameter descriptors,
return sites, and per-method structural facts.

They intentionally do NOT claim source-level argument provenance such as:
`caller local x -> callee parameter 2`
because establishing that reliably requires a JVM verifier-grade stack/local symbolic dataflow
analysis across branches, merges, wide values, exception edges, invokedynamic, and object aliases.

The bytecode evidence is retained so that such analysis can be performed later on selected methods
without contaminating the authority layer with heuristic labels.

# Void Hunters Final Forensic Index Batch

Source JAR SHA-256: 4bb086ef9b0ec1f6f5362df92d634a2b4d997b4b5037f213fd3d5e5ea219bba4
Exact JAR classes: 1570
Parsed methods (including constructors/clinit): 11008
Methods with bytecode: 10348
Parsed bytecode instructions: 758154

This batch contains the remaining high-value mechanical indexes:
- argument/invocation sites and JVM parameter descriptors
- return sites
- virtual/interface dispatch sites
- exception tables
- switch sites
- synchronization sites
- method structural dataflow facts

No semantic gameplay labels are assigned.

IMPORTANT:
"argument data-flow" here means exact invocation evidence and descriptor-defined argument structure,
not heuristic local-variable provenance. A full symbolic JVM stack/local analysis is deliberately left
as a separate operation so it can be applied rigorously to selected methods.

Authority:
original JAR/classfiles > javap > decompiler readability > forensic interpretation > DarkWing.

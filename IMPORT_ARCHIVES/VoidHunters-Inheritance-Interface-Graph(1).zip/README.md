# Void Hunters Inheritance / Interface Graph

Original JAR SHA-256: 4bb086ef9b0ec1f6f5362df92d634a2b4d997b4b5037f213fd3d5e5ea219bba4
Exact JAR class entries: 1570

Outputs:
- CLASS_HIERARCHY.tsv — class declarations and printed superclass/interface clauses.
- INHERITANCE_EDGES.tsv — parsed EXTENDS/IMPLEMENTS edges.
- DIRECT_OVERRIDE_MAP.tsv — exact child/parent method signature matches where a direct superclass was parsed.
- ANCESTOR_CHAINS.tsv — transitive superclass chains over parsed edges.

Completeness boundary:
The exact class universe comes directly from the JAR. Relationship/member extraction is from the complete javap dump. Java's compiled classfile metadata can contain interfaces/superclasses even when a human-readable declaration parser is imperfect; therefore this is a mechanical index and not a semantic interpretation. Unresolved or external parents remain exactly as printed rather than being invented.

Authority: original JAR/classfiles > javap > decompiler > inference > DarkWing.

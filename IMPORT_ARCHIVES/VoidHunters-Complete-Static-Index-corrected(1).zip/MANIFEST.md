# Void Hunters Complete Static Index

Source JAR SHA-256: 4bb086ef9b0ec1f6f5362df92d634a2b4d997b4b5037f213fd3d5e5ea219bba4
Exact JAR class entries: 1570
Parsed class declarations: 1570
Parsed methods: 8283
Methods with bytecode: 7670

This package is a mechanically derived forensic index. It deliberately does not assign gameplay meanings.

Included datasets:
- constructors / allocations
- static initialization
- string provenance
- constant provenance and shift/bitwise operation indexes
- exact JAR resource inventory and statically detectable string/resource references
- inheritance/interface dispatch candidates

Completeness:
- Exact JAR class/resource inventories come from the JAR ZIP directory.
- Bytecode-derived datasets are exhaustive for the instructions represented in the complete javap dump.
- Resource references are only statically detectable string-to-resource matches.
- Dispatch map reports exact signature candidates from parsed class hierarchy metadata; JVM runtime dispatch, reflection, generated proxies, JNI/native behavior, and dynamic class loading are not inferred.
- Constant provenance records the actual constant-loading instruction/operand; it does not assign units or semantic meaning.
- No DarkWing implementation is treated as source authority.

Authority:
original JAR/classfiles > javap > decompiler readability > forensic interpretation > DarkWing implementation.

## CORRECTION — constructor/static initializer parsing
Constructor and `<clinit>` declarations are explicitly included. Earlier method parsers that required a Java identifier did not capture angle-bracket method names; this package has been corrected before delivery.

## FINAL CORRECTION — JVM special method names
Constructor references are matched against javap's quoted `"<init>"` form, and static initializers are matched against javap's `static {};` declaration form. Earlier zero counts from Java-identifier-only parsing are superseded by this corrected dataset.

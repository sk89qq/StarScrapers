# Void Hunters JVM Stack / Local Symbolic Dataflow

Original JAR SHA-256: 4bb086ef9b0ec1f6f5362df92d634a2b4d997b4b5037f213fd3d5e5ea219bba4
Exact JAR class entries: 1570
Methods analyzed: 10348
Snapshots: 438275
Dataflow edges: 251013
Sinks: 232762

This is a conservative abstract interpretation over original-JAR-derived javap bytecode.
It tracks operand-stack and local-slot symbolic provenance through common JVM operations and
records field reads/writes, calls and call arguments, returns, branches, allocations, arrays,
casts, shifts and bitwise/arithmetic expressions.

Rigor boundary:
- This is NOT a claim of perfect source reconstruction.
- Conflicting control-flow merges become TOP rather than being guessed.
- Unsupported opcodes are counted rather than assigned invented semantics.
- The initial local-slot model is conservative; Java static-vs-instance access flags are not inferred
  from syntax alone.
- Reflection, invokedynamic bootstrap semantics, native/JNI behavior, object alias analysis,
  precise exception-flow joins, and JVM verifier corner cases are not silently modeled.
- Raw bytecode remains authoritative whenever a value becomes TOP or an opcode is unsupported.

Use this dataset to prioritize and trace methods; do not treat symbolic labels as gameplay meanings.

# Void Hunters Machine-Readable CFG

Original JAR SHA-256: 4bb086ef9b0ec1f6f5362df92d634a2b4d997b4b5037f213fd3d5e5ea219bba4
Exact class entries in JAR: 1570

Parsed methods with bytecode: 7670
Parsed instructions: 679374
Basic blocks: 123779
CFG edges: 266633
Exception-handler edges: 148479

The block partition uses JVM bytecode offsets, branch targets, conditional fall-throughs, switch targets, and exception handler targets as leaders. Edges are explicit and machine-readable. No semantic interpretation is added.

Completeness boundary: exhaustive for bytecode and control-flow structures represented in the supplied complete javap dump. It does not model reflection, native/JNI behavior, runtime class loading, or dynamic control flow outside the JVM bytecode.
